var z=0;
function increment(){
    var x=0;
console.log("0")
while(true)
{console.log("2")
    x++;
    console.log(x);
    document.getElementById('display').innerHTML=x;
if(z==1)
{document.getElementById('display').innerHTML='';
break;}
}
}
function preset()
{console.log("2")
    z=1;
   //increment();

}
